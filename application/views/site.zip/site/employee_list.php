<?php include "includes/edm_head.php" ?>
<?php include "includes/edm_header.php" ?>
<?php include "includes/edm_top_menu.php" ?>
<?php include "includes/edm_top_notice.php" ?>
<div id="edm_s4s_body" class="container-fluid">
	<div class="row">
		<div class="col-sm-3">
			<?php include "includes/edm_left_side.php" ?>
		</div>
		<div class="edm_s4s_middle col-sm-7">
			<?php include "includes/edm_breadcrumbs.php" ?>
			<?php include "includes/edm_list_employee.php" ?>
		</div>
		<div class="col-sm-2">
			<?php include "includes/edm_right_side.php" ?>
		</div>
	</div>
</div>
<?php include "includes/edm_bottom.php" ?>
<?php include "includes/edm_footer.php" ?>
<?php include "includes/edm_foot.php" ?>                                       


