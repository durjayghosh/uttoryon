    <header id="edm_s4s_header" class="hidden-xs">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <!-- <a href="<?php echo base_url(); ?>"><img class="img-responsive" src="<?php echo base_url(); ?>assets/super_admin/vendor/jquery-file-upload/server/php/files/banner.png" alt="Banner"></a> -->

                    <a href="<?php echo base_url(); ?>"><img class="img-responsive" src="<?php echo base_url(); ?>uploads/banner.png" alt="Banner"></a>
                </div>
            </div>
        </div><!--/.container-->     
    </header><!--/header-->