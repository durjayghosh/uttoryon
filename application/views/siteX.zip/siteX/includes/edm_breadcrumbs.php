                    <div class="section-header">
                        <h2 class="section-title text-center wow fadeInDown"><?=$page_title?></h2>
                    </div>
                    <ol class="breadcrumb">
					  <li><a href="<?php echo base_url() ?>">Home</a></li>
					  <li class="active"><?=$page_name?></li>
					</ol>