                    <div class="section-header">
                        <h2 class="section-title text-center wow fadeInDown">Board Results</h2>
                    </div>
                    <ol class="breadcrumb">
					  <li><a href="<?php echo base_url() ?>">Home</a></li>
					  <li class="active">Board Results</li>
					</ol>                   
                    <section id="edm_page_content">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="edm_s4s_content col-sm-12">
                                   <iframe src="http://www.educationboardresults.gov.bd/regular/index.php" style="border: 0; width:100%; height:800px;"></iframe>
                                </div>
                            </div>
                        </div>
                    </section>