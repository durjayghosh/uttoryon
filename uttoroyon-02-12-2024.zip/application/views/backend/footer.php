<!-- Footer -->
<footer class="main">
	&copy; <?php echo date('Y'); ?> <strong>School Management System</strong>. 
    Developed by 
	<a href="http://www.exdmania.com" 
    	target="_blank">Extreme Design Mania</a>
</footer>
