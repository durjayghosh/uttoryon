    <footer id="edm_s4s_footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6">
                © <?php echo date('Y') ?> <?= $system_name ?>. Developed by <a target="_blank" href="https://seoexpate.com/" title="SEBL SOFT 4 SCHOOL">SEO Expate Bangladesh Ltd.</a>
                </div>
                <div class="col-sm-6">
                    <ul class="social-icons">
                        <li><a target="_blank" href="https://facebook.com/<?=$facebook?>"><i class="fa fa-facebook"></i></a></li>
                        <li><a target="_blank" href="https://twitter.com/<?=$twitter?>"><i class="fa fa-twitter"></i></a></li>
                        <!-- <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                        <li><a href="#"><i class="fa fa-youtube"></i></a></li> -->
                    </ul>
                </div>
            </div>
        </div>
    </footer><!--/#footer-->