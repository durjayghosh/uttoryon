    <script src="<?php echo base_url(); ?>assets/site/js/bootstrap.min.js"></script>
    <script src="https://maps.google.com/maps/api/js?sensor=true"></script>
    <script src="<?php echo base_url(); ?>assets/site/js/owl.carousel.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/site/js/mousescroll.js"></script>
    <script src="<?php echo base_url(); ?>assets/site/js/smoothscroll.js"></script>
    <script src="<?php echo base_url(); ?>assets/site/js/jquery.prettyPhoto.js"></script>
    <script src="<?php echo base_url(); ?>assets/site/js/jquery.isotope.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/site/js/jquery.inview.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/site/js/wow.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/site/js/main.js"></script>
</body>
</html>