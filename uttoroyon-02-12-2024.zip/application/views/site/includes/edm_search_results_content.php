                    <section id="edm_page_content">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="edm_s4s_content col-sm-12">
                                    <h3 class="column-title">Principal's Message</h3>
                                    <div data-wow-delay="100ms" data-wow-duration="300ms" class="blog-post blog-media wow fadeInRight animated" style="visibility: visible; animation-duration: 300ms; animation-delay: 100ms; animation-name: fadeInRight;">
                                        <article class="media clearfix">
                                            <div class="entry-thumbnail pull-left">
                                                <img alt="" src="images/blog/02.jpg" class="img-responsive">
                                            </div>
                                            <div class="media-body">
                                                <header class="entry-header">
                                                    <h2 class="entry-title"><a href="#">Name of the Principal</a></h2>
                                                </header>
                                                <div class="entry-content">
                                                    <p>With a blow from the top-maul Ahab knocked off the steel head of the lance, and then handing to the steel</p>
                                                </div>
                                            </div>
                                        </article>
                                    </div>                                    
                                </div>
                            </div>
                        </div>
                    </section>