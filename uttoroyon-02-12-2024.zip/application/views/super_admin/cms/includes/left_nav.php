
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                            </div>
                            <!-- /input-group -->
                        </li>
                        <li>
                            <a href="<?php echo base_url(); ?>admin/dashboard"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                        
                        <li>
                            <a href="<?php echo base_url(); ?>admin/view_pages"><i class="fa fa-book"></i> View Pages</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url(); ?>admin/governing_body"><i class="fa fa-sitemap"></i> Add Governing Body</a>
                        </li>

                        <li>
                            <a href="<?php echo base_url(); ?>admin/view_governing_body"><i class="fa fa-sitemap"></i> View Governing Body</a>
                        </li>

                         <li>
                            <a href="<?php echo base_url(); ?>admin/notice"><i class="fa fa-share-square-o"></i> Add Notice</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url(); ?>admin/view_notices"><i class="fa fa-share-square"></i> View Notices</a>
                        </li>

                        <li>
                            <a href="<?php echo base_url(); ?>admin/news"><i class="fa fa-newspaper-o"></i> Add News</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url(); ?>admin/view_newses"><i class="fa fa-newspaper-o"></i> View News</a>
                        </li>

                         <li>
                            <a href="<?php echo base_url(); ?>admin/event"><i class="fa fa-comments-o"></i> Add Event</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url(); ?>admin/view_events"><i class="fa fa-comments"></i> View Events</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url(); ?>admin/gallary_upload"><i class="fa fa-image"></i> Add/Edit Gallery</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url(); ?>admin/site_links"><i class="fa fa-image"></i> Add/Edit Site Links</a>
                        </li>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

