<?php include "includes/header_links.php"; ?>
	
<?php include "includes/main_menu.php"; ?>		
<?php include "includes/menu_top_logo.php"; ?>	
<?php include "includes/top_bar.php"; ?>			
					
				<div class="main-content" >
					<div class="wrap-content container" id="container">
<?php include "includes/count_bar.php"; ?>	
<?php include "includes/featured_box.php"; ?>						
						
						<!-- start: FIRST SECTION -->
						<div class="container-fluid container-fullw padding-bottom-10">
							<div class="row">
								<div class="col-sm-12">
									<div class="row">
										<div class="col-md-7 col-lg-8">
											<div class="col-md-12 col-xs-12">    
								                <div class="panel panel-primary " data-collapsed="0">
								                    <div class="panel-heading">
								                        <div class="panel-title">
								                            <i class="fa fa-calendar"></i>
								                            
								                        </div>
								                    </div>
								                    <div class="panel-body" style="padding:0px;">
								                        <div class="calendar-env">
								                            <div class="calendar-body">
								                                <div id="notice_calendar"></div>
								                            </div>
								                        </div>
								                    </div>
								                </div>
								            </div>
								        </div>
										</div>
										<div class="col-md-5 col-lg-4">
											right div
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- end: FIRST SECTION -->
						
						
					</div>
				</div>
<?php include "includes/footer.php"; ?>		
			<!-- end: FOOTER -->
<?php include "includes/hidden_sidebar.php"; ?>				
<?php include "includes/settings.php"; ?>				
<?php include "includes/footer_js.php"; ?>		

