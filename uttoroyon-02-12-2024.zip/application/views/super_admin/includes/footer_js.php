		<!-- start: MAIN JAVASCRIPTS -->
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/jquery/jquery.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/modernizr/modernizr.js"></script>
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/Chart.js/Chart.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/jquery.sparkline/jquery.sparkline.min.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="<?php echo base_url(); ?>assets/super_admin/assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="<?php echo base_url(); ?>assets/super_admin/assets/js/index.js"></script>

		
        <script src="<?php echo base_url(); ?>assets/super_admin/vendor/select2/select2.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/super_admin/vendor/DataTables/jquery.dataTables.min.js"></script>
       <script src="<?php echo base_url(); ?>assets/super_admin/assets/js/table-data.js"></script>

       <script src="<?php echo base_url(); ?>assets/super_admin/vendor/sweetalert/sweet-alert.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/toastr/toastr.min.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="<?php echo base_url(); ?>assets/super_admin/assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="<?php echo base_url(); ?>assets/super_admin/assets/js/ui-notifications.js"></script>
		<script>
			/*jQuery(document).ready(function() {
				Main.init();
				UINotifications.init();
			});*/
		</script>
        
        
        <script>
            jQuery(document).ready(function() {
                Main.init();
                TableData.init();
            });
        </script>


        
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/jquery-file-upload/vendor/jquery.ui.widget.js"></script>
		<!-- The Templates plugin is included to render the upload/download listings -->
		<script src="http://blueimp.github.io/JavaScript-Templates/js/tmpl.min.js"></script>
		<!-- The Load Image plugin is included for the preview images and image resizing functionality -->
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/javascript-Load-Image/load-image.all.min.js"></script>
		<!-- The Canvas to Blob plugin is included for image resizing functionality -->
		<script src="http://blueimp.github.io/JavaScript-Canvas-to-Blob/js/canvas-to-blob.min.js"></script>
		<!-- blueimp Gallery script -->
		<script src="http://blueimp.github.io/Gallery/js/jquery.blueimp-gallery.min.js"></script>
		<!-- The Iframe Transport is required for browsers without support for XHR file uploads -->
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/jquery-file-upload/jquery.iframe-transport.js"></script>
		<!-- The basic File Upload plugin -->
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/jquery-file-upload/jquery.fileupload.js"></script>
		<!-- The File Upload processing plugin -->
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/jquery-file-upload/jquery.fileupload-process.js"></script>
		<!-- The File Upload image preview & resize plugin -->
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/jquery-file-upload/jquery.fileupload-image.js"></script>
		<!-- The File Upload audio preview plugin -->
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/jquery-file-upload/jquery.fileupload-audio.js"></script>
		<!-- The File Upload video preview plugin -->
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/jquery-file-upload/jquery.fileupload-video.js"></script>
		<!-- The File Upload validation plugin -->
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/jquery-file-upload/jquery.fileupload-validate.js"></script>
		<!-- The File Upload user interface plugin -->
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/jquery-file-upload/jquery.fileupload-ui.js"></script>
		<!-- The main application script -->
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/jquery-file-upload/main.js"></script>
		<!-- The XDomainRequest Transport is included for cross-domain file deletion for IE 8 and IE 9 -->
		<!--[if (gte IE 8)&(lt IE 10)]>
		<script src="<?php echo base_url(); ?>assets/super_admin/js/cors/jquery.xdr-transport.js"></script>
		<![endif]-->
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="<?php echo base_url(); ?>assets/super_admin/assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="<?php echo base_url(); ?>assets/super_admin/assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="<?php echo base_url(); ?>assets/super_admin/assets/js/pages-messages.js"></script>

		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/jquery-ui/jquery-ui-1.10.2.custom.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/moment/moment.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/jquery-validation/jquery.validate.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/fullcalendar/fullcalendar.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/bootstrap-datetimepicker/bootstrap-datetimepicker.min.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="<?php echo base_url(); ?>assets/super_admin/assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="<?php echo base_url(); ?>assets/super_admin/assets/js/pages-calendar.js"></script>
 <script src="<?php echo base_url(); ?>assets/ckeditor/ckeditor.js"></script>
		<script>CKEDITOR.replace('content', {
  "filebrowserImageUploadUrl": "../../assets/ckeditor/plugins/imgupload/imgupload.php"
});
		</script> 

		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/sweetalert/sweet-alert.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/super_admin/vendor/toastr/toastr.min.js"></script>

		             
		
	</body>
</html>