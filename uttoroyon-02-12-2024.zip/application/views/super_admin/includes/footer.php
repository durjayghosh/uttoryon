</div>

</div>



</div> <!-- div id apps close link to header_links.php page -->

			<!-- start: FOOTER -->

			<footer>

				<div class="footer-inner">

					<div class="pull-left">

						&copy; <span class="current-year"></span><span class="text-bold text-uppercase"> </span>. <span>Developed by <a target="_blank" href="http://seoexpate.com/"> SEO Expate Bangladesh Ltd.</a> All rights reserved</span>

					</div>

					<div class="pull-right">

						<span class="go-top"><i class="ti-angle-up"></i></span>

					</div>

				</div>

			</footer>